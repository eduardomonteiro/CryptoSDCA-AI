"""
src/__init__.py - Source package initialization
"""

from .models import Base

__all__ = ["Base"]
